import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt
from stable_baselines3 import PPO
from environment.env import Environment
from comyx.utils import dbm2pow, pow2dbm
import itertools
from environment.helper import *

import warnings
warnings.filterwarnings("ignore")

# Load the trained model
model = PPO.load("C:/Users/ant/Desktop/Active RIS/cioffi_phd/cioffi_phd/logs/ppo")


# Create and register the environment
cfg = {
    'M': 4,  # Number of antennas at the BS
    'K': 4,  # Number of users
    'N': 256,  # Number of elements at the RIS
    'max_steps': 100,  # Maximum number of steps in an episode
    'noise_power': 1e-9,  # Noise power
    'total_power_limit': 55  # Total power limit in dBm
}

gym.register(id="RISPrecoding-v0", entry_point=Environment, kwargs={'cfg': cfg})
env = gym.make("RISPrecoding-v0")

def evaluate_rl(model, env, target_sum_rate, num_episodes=5):
    total_power = 0
    episodes_met_target = 0
    capacity_gain_list = []
    power_usage_list = []
    reward_list = []

    for _ in range(num_episodes):
        obs = env.reset()
        done = False
        episode_power = 0
        step_count = 0
        total_capacity = 0
        total_reward = 0

        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, done, info = env.step(action)
            
            # Sum up the power used and capacity gain in this step
            episode_power += info.get('total_power', 0)
            total_capacity += np.sum([info.get(f"R_{i+1}", 0) for i in range(env.cfg['K'])])
            total_reward += reward
            step_count += 1

        # Calculate average power for this episode
        avg_episode_power = episode_power / step_count if step_count > 0 else 0
        avg_capacity_gain = total_capacity / step_count if step_count > 0 else 0
        avg_reward = total_reward / step_count if step_count > 0 else 0
        
        power_usage_list.append(avg_episode_power)
        capacity_gain_list.append(avg_capacity_gain)
        reward_list.append(avg_reward)

        # Check if the target sum rate was met
        if avg_capacity_gain >= target_sum_rate:
            total_power += avg_episode_power
            episodes_met_target += 1

    # Calculate the average power across episodes that met the target
    if episodes_met_target > 0:
        avg_power = total_power / episodes_met_target
        return pow2dbm(avg_power), episodes_met_target, power_usage_list, capacity_gain_list, reward_list
    else:
        return float('inf'), 0, power_usage_list, capacity_gain_list, reward_list

def brute_force(env, power_range, target_sum_rate):
    best_power = float('inf')
    best_config = None
    capacity_gain_list = []
    power_usage_list = []

    for p1, p2, p3 in itertools.product(power_range, repeat=3):
        env.P_1, env.P_2, env.P_3 = p1, p2, p3
        env.R_1, env.R_2, env.R_3 = 0, 0, 0
        obs = env.reset()
        done = False
        total_capacity = 0
        step_count = 0
        total_power = 0

        while not done:
            obs, reward, done, info = env.step([0, 0, 0])
            total_capacity += info.get('R_1', 0) + info.get('R_2', 0) + info.get('R_3', 0)
            total_power += info.get('total_power', 0)
            step_count += 1

        avg_capacity_gain = total_capacity / step_count if step_count > 0 else 0
        avg_power = total_power / step_count if step_count > 0 else 0
        capacity_gain_list.append(avg_capacity_gain)
        power_usage_list.append(avg_power)

        if avg_capacity_gain >= target_sum_rate and avg_power < best_power:
            best_power = avg_power
            best_config = (p1, p2, p3)

    return best_power, best_config, power_usage_list, capacity_gain_list

# Parameters for evaluation
target_sum_rate = 500  # Target sum-rate in Mbps
num_episodes = 5  # Number of episodes for evaluation
power_range = np.linspace(10, 50, 10)  # Range of powers for brute force search

# Evaluate the RL model
avg_power, episodes_met_target, power_usage_rl, capacity_gain_rl, reward_rl = evaluate_rl(model, env, target_sum_rate, num_episodes)

# Perform brute force search for comparison
best_power, best_config, power_usage_bf, capacity_gain_bf = brute_force(env, power_range, target_sum_rate)

print(f"RL Average Power (dBm): {avg_power}")
print(f"RL Episodes Met Target: {episodes_met_target}")
print(f"Brute Force Best Power (dBm): {pow2dbm(best_power)}")
print(f"Brute Force Best Config: {best_config}")

# Plot the results

# Plot reward over episodes
plt.figure()
plt.plot(reward_rl, label="RL Reward")
plt.xlabel('Episode')
plt.ylabel('Average Reward')
plt.title('Average Reward over Episodes')
plt.legend()
plt.grid(True)
plt.show()

# Plot total power usage over episodes
plt.figure()
plt.plot(power_usage_rl, label="RL Total Power Usage")
plt.plot(power_usage_bf, label="Brute Force Total Power Usage", linestyle='--')
plt.xlabel('Episode')
plt.ylabel('Total Power Usage (dBm)')
plt.title('Total Power Usage over Episodes')
plt.legend()
plt.grid(True)
plt.show()

# Plot capacity gain over episodes
plt.figure()
plt.plot(capacity_gain_rl, label="RL Capacity Gain")
plt.plot(capacity_gain_bf, label="Brute Force Capacity Gain", linestyle='--')
plt.xlabel('Episode')
plt.ylabel('Capacity Gain (Mbps)')
plt.title('Capacity Gain over Episodes')
plt.legend()
plt.grid(True)
plt.show()