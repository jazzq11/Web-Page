load minPMAC_out.mat

H_1 = squeeze(H(:,1, :));
H_2 = squeeze(H(:,2, :));
H_3 = squeeze(H(:,3, :));

magsqr_h_1 = sum(sum(norm(H_1), 2), 1) .^ 2;
magsqr_h_2 = sum(sum(abs(H_2), 2), 1) .^ 2;
magsqr_h_3 = sum(sum(abs(H_3), 2), 1) .^ 2;

Eu_1 = sum(Eun(1, :), "all");
Eu_2 = sum(Eun(2, :), "all");
Eu_3 = sum(Eun(3, :), "all");

theta_noma = [Eu_1*magsqr_h_1; Eu_2*magsqr_h_2; Eu_3*magsqr_h_3];