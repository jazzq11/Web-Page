import numpy as np
from scipy.linalg import logm, det

def eval_f(theta, H, e, w):
    """
    Evaluate the function f given by the equation:
    
    f(e) = (theta_1 - theta_2)/2 * log(det(I + G_1 * G_1^H * e_1)) + 
           (theta_2 - theta_3)/2 * log(det(I + G_1 * G_1^H * e_1 + G_2 * G_2^H * e_2)) + ...
           (theta_{U-1} - theta_U)/2 * log(det(I + G_1 * G_1^H * e_1 + ... + G_{U-1} * G_{U-1}^H * e_{U-1})) +
           theta_U/2 * log(det(I + G_1 * G_1^H * e_1 + ... + G_U * G_U^H * e_U)) - w^T * e + sum_{u=1}^U log(e_u)
    
    Parameters:
    theta (numpy.ndarray): A U x 1 vector of weights for the rates.
    H (numpy.ndarray): An Ly x U channel matrix. H[:,u] is the channel vector for user u.
    e (numpy.ndarray): A U x 1 vector containing each user's power.
    w (numpy.ndarray): A U x 1 vector containing weights for each user's power.

    Returns:
    float: The function value.
    """
    Ly, U = H.shape

    # Adjust theta to be the differences and prepend a 0
    theta = 0.5 * (theta - np.concatenate((theta[1:], [0])))

    # Initialize M
    M = np.zeros((Ly, Ly, U), dtype=np.complex128)
    M[:, :, 0] = np.eye(Ly) + np.outer(H[:, 0], H[:, 0]) * e[0]
    
    # Calculate the function value
    f = theta[0] * np.log(det(M[:, :, 0])) + np.log(e[0]) - w[0] * e[0]
    for u in range(1, U):
        M[:, :, u] = M[:, :, u - 1] + np.outer(H[:, u], H[:, u]) * e[u]
        f += theta[u] * np.log(det(M[:, :, u])) + np.log(e[u]) - w[u] * e[u]
    
    return f
