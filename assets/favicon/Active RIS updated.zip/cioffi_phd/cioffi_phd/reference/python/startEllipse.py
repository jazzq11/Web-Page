import numpy as np
from scipy.linalg import sqrtm
from waterfill_gn import fmwaterfill_gn

def startEllipse(H, bu, w, cb):
    Ly, U, N = H.shape

    order = np.arange(U)  # decoding order, arbitrary
    tmax = np.zeros(U, dtype=np.complex128)

    for u in range(U):
        en = np.zeros((U, N), dtype=np.complex128)
        b = bu.astype(np.complex128).copy()  # Ensure b is a complex128 array
        b[u] += 1
        g = np.zeros((U, N))

        for u1 in order[::-1]:  # starting from the last user
            Rnoise = np.array([np.eye(Ly, dtype=np.complex128) for _ in range(N)])

            for u2 in order[::-1]:  # users that have been decoded have zero E
                if u2 != u1:
                    for index in range(N):
                        Rnoise[index] += en[u2, index] * np.outer(H[:, u2, index], H[:, u2, index])

            for index in range(N):
                Rnoise_sqrt = sqrtm(Rnoise[index]).astype(np.complex128)
                h_temp = np.linalg.solve(Rnoise_sqrt, H[:, u1, index])
                g[u1, index] = np.linalg.norm(h_temp, ord=2)**2

            b_temp, E_temp, _ = fmwaterfill_gn(g[u1, :], b[u1] / N, 0, cb)
            en[u1, :] = E_temp

        tmax[u] = np.sum(w * np.sum(en.real, axis=1))  # \sum_n \sum_u \w_u En_u

    g_center = tmax.real / 2

    A = np.eye(U) * np.sum(g_center**2)  # a sphere centered at tmax/2

    return A, g_center, w
