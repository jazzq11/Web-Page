import numpy as np

def Hessian(theta, G, e, w):
    """
    This function calculates the gradient (g) and the Hessian (H) of the
    function f(e) = (theta_1 - theta_2)/2 * log det(I + G_1 * G_1^H * e_1) + 
    (theta_2 - theta_3)/2 * log det(I + G_1 * G_1^H * e_1 + G_2 * G_2^H * e_2) + ...
    (theta_{U-1} - theta_U)/2 * log det(I + G_1 * G_1^H * e_1 + ... + G_{U-1} * G_{U-1}^H * e_{U-1}) +
    theta_U/2 * log det(I + G_1 * G_1^H * e_1 + ... + G_U * G_U^H * e_U) - w^T * e + sum_{u=1}^U log(e_u)
    theta should be in decreasing order, theta_1 >= theta_2 >= ... >= theta_U.

    Parameters:
    theta (numpy.ndarray): A U x 1 vector of weights for the rates.
    G (numpy.ndarray): An Ly x U channel matrix.
    e (numpy.ndarray): A U x 1 vector containing each user's power.
    w (numpy.ndarray): A U x 1 vector containing weights for each user's power.

    Returns:
    tuple: (g, H) where g is the gradient vector and H is the Hessian matrix.
    """
    Ly, U = G.shape

    # Adjust theta to match MATLAB behavior (theta should be in decreasing order)
    theta = 0.5 * (theta - np.append(theta[1:], 0))

    M = np.zeros((Ly, Ly, U), dtype=np.complex128)  # Initialize M
    M[:, :, 0] = np.eye(Ly) - np.outer(G[:, 0], G[:, 0].conj()) * e[0] / (1 + e[0] * np.dot(G[:, 0].conj().T, np.dot(G[:, 0], e[0])))

    for u in range(1, U):
        M[:, :, u] = M[:, :, u-1] - np.dot(np.dot(M[:, :, u-1], np.outer(G[:, u], G[:, u].conj())), np.dot(M[:, :, u-1], e[u])) / (1 + e[u] * np.dot(np.dot(G[:, u].conj().T, M[:, :, u-1]), np.dot(G[:, u], e[u])))

    # Calculate gradient g
    g = np.zeros(U, dtype=np.complex128)
    for u in range(U):
        for j in range(u, U):
            g[u] += theta[j] * np.dot(G[:, u].conj().T, np.dot(M[:, :, j], G[:, u]))
    
    g += 1 / e - w

    # Calculate Hessian H
    H = np.zeros((U, U), dtype=np.complex128)
    for u in range(U):
        for l in range(U):
            for j in range(max(u, l), U):
                H[u, l] -= theta[j] * np.trace(np.dot(np.outer(G[:, u], G[:, u].conj()), np.dot(M[:, :, j], np.dot(np.outer(G[:, l], G[:, l].conj()), M[:, :, j]))))
    
    H -= np.diag(1 / e**2)

    return g, H
