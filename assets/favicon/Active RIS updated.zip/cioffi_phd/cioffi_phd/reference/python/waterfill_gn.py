import numpy as np

def fmwaterfill_gn(gn, E_bar, gap, cb=2):
    """
    This function allows the energy budget to be divided by the total number of dimensions 
    (unlike waterfill, for which only the total energy is specified). 

    Parameters:
    gn (numpy.ndarray): Channel gain (a row vector).
    E_bar (float): The normalized power constraint (E_total / Ntot).
    gap (float): The gap in dB.
    cb (int): 1 for complex bb and 2 for real bb (default is 2).

    Returns:
    tuple: bn (bit allocation), en (energy allocation), Nstar (number of energized dimensions).
    """

    gap = 10 ** (gap / 10)
    if len(gn.shape) != 1:
        raise ValueError("gn must be a row vector")
    
    Ntot = gn.size
    en = np.zeros(Ntot)
    bn = np.zeros(Ntot)

    # Sort and reverse to get largest gain first
    Index = np.argsort(gn)[::-1]
    gn_sorted = gn[Index]

    num_zero_gn = np.sum(gn_sorted == 0)
    Nstar = Ntot - num_zero_gn

    while True:
        K = 1 / Nstar * (Ntot * E_bar + gap * np.sum(1 / gn_sorted[:Nstar]))
        En_min = K - gap / gn_sorted[Nstar - 1]

        if En_min < 0:
            Nstar -= 1
        else:
            break

    En = K - gap / gn_sorted[:Nstar]
    Bn = (1 / cb) * np.log2(K * gn_sorted[:Nstar] / gap)

    bn[Index[:Nstar]] = Bn
    en[Index[:Nstar]] = En

    return bn, en, Nstar





