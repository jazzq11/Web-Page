import numpy as np
from Hessian import Hessian
from eval_f import eval_f

def minPtone(H, theta, w):
    Ly, U = H.shape
    stheta, ind = np.sort(-theta), np.argsort(-theta)
    stheta = -stheta
    sH = H[:, ind]
    sw = w[ind]

    NT_max_it = 1000  # Maximum number of Newton's method iterations
    dual_gap = 1e-6
    mu = 10  # Step size for t
    alpha = 0.01  # Back tracking line search parameters
    beta = 0.5

    count = 1
    nerr = 1e-5  # Acceptable error for inner loop Newton's method

    e = np.ones(U)  # Strictly feasible point

    t = 0.1
    l_p = 1  # For Newton's method termination

    while (1 + U) / t > dual_gap:
        t *= mu
        l_p = 1
        count = 1
        
        while l_p > nerr and count < NT_max_it:
            f_val = eval_f(t * stheta, sH, e, t * sw)  # Calculate function value
            
            # Calculate the Hessian and gradient
            g, h = Hessian(t * stheta, sH, e, t * sw)
            
            de = -np.real(np.linalg.solve(h, g))  # Search direction
            
            l_p = np.dot(g.conj().T, de)  # theta(e)^2 for Newton's method
            
            s = 1  # Checking e = e + s * de feasible and also backtracking algorithm
            
            e_new = e + s * de
            
            if np.all(e_new > 0):
                f_new = eval_f(t * stheta, sH, e_new, t * sw)
                feas_check = f_new > f_val + alpha * s * np.dot(g.conj().T, de)
            else:
                feas_check = False
            
            while not feas_check:
                s *= beta
                if s < 1e-40:
                    l_p = nerr / 2
                    break
                e_new = e + s * de
                
                if np.all(e_new > 0):
                    f_new = eval_f(t * stheta, sH, e_new, t * sw)
                    feas_check = f_new > f_val + alpha * s * np.dot(g.conj().T, de)
                else:
                    feas_check = False
            
            e += s * de  # Update e
            count += 1  # Number of Newton's method iterations

    M = np.eye(Ly) + np.outer(sH[:, 0], sH[:, 0].conj()) * e[0]
    b = np.zeros(U)
    b[0] = 0.5 * np.real(np.log(np.linalg.det(M)))
    
    for u in range(1, U):
        b[u] = -0.5 * np.real(np.log(np.linalg.det(M)))
        M += np.outer(sH[:, u], sH[:, u].conj()) * e[u]
        b[u] += 0.5 * np.real(np.log(np.linalg.det(M)))
    
    b[ind] = b
    e[ind] = e
    f = np.dot(theta, b) - np.dot(w, e)
    
    return f, b, e
