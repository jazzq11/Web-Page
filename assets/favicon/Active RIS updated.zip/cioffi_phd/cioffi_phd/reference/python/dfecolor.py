
import numpy as np
from scipy.linalg import toeplitz

def dfecolor(l, h, nff, nbb, delay, Ex, noise):
    size_h = len(h)
    nu = int(np.ceil(size_h / l)) - 1
    h = np.concatenate((h, np.zeros((nu + 1) * l - size_h)))

    # Error checks
    if nff <= 0:
        raise ValueError('number of feedforward taps must be > 0')
    if nbb < 0:
        raise ValueError('number of feedback taps must be >= 0')
    if delay > (nff + nu - 1):
        raise ValueError('delay must be <= (nff + (length of p) - 2)')
    elif delay < -1:
        raise ValueError('delay must be >= -1')
    elif delay == -1:
        delay = np.arange(nff + nu)

    # Form ptmp = [p_0 p_1 ... p_nu] where p_i = [p(i*l) p(i*l-1) ... p((i-1)*l+1)]
    ptmp = np.zeros((l, nu + 1), dtype=complex)
    ptmp[:, 0] = np.concatenate(([h[0]], np.zeros(l - 1)))
    for i in range(1, nu + 1):
        ptmp[:, i] = np.conj(h[i * l:(i - 1) * l:-1])

    dfseSNR = -100
    w_t = None
    opt_delay = None
    nbb_final = nbb

    # Loop over all possible delays
    for d in delay:
        # Compute exact number of feedback taps we need to consider given delay d
        nbb_used = min(nff + nu - 1 - d, nbb)
        # Form matrix P, vector channel matrix
        P = np.zeros((nff * l + nbb_used, nff + nu), dtype=complex)
        for i in range(nff):
            P[i * l:(i + 1) * l, i:i + nu + 1] = ptmp
        P[nff * l:nff * l + nbb_used, d + 1:d + 1 + nbb_used] = np.eye(nbb_used)

        # Compute Rn matrix
        Rn = np.zeros((nff * l + nbb_used, nff * l + nbb_used), dtype=complex)
        Rn[:nff * l, :nff * l] = toeplitz(noise[:nff * l])
        temp = np.zeros(nff + nu, dtype=complex)
        temp[d] = 1

        # Construct matrices
        Ry = Ex * P @ P.T.conj() + Rn
        Rxy = Ex * temp @ P.T.conj()
        new_w_t = np.linalg.solve(Ry, Rxy)
        sigma_dfse = Ex - np.real(new_w_t @ Rxy.T.conj())
        new_dfseSNR = 10 * np.log10(Ex / sigma_dfse - 1)

        # Save setting of this delay if best performance so far
        if new_dfseSNR >= dfseSNR:
            w_t = new_w_t
            dfseSNR = new_dfseSNR
            opt_delay = d
            nbb_final = nbb_used

    if nbb_final < nbb:
        print(f'Warning: For OPTIMAL FB filter settings N_bb={nbb_final} was used instead of the N_bb={nbb} inputted')

    return dfseSNR, w_t, opt_delay