import numpy as np
from scipy.linalg import inv, svd, sqrtm, det
from waterfill_gn import fmwaterfill_gn

def SWF(Eu, H, Lxu, Rnn, cb):
    U = len(Lxu)
    Ly, Lx_sum, N = H.shape

    if np.isscalar(Eu):
        Eu = Eu * np.ones(U, dtype=np.float64)  # Ensure Eu is float64 for consistency

    Rxx = np.zeros((Lx_sum, Lx_sum, N), dtype=np.complex128)
    for n in range(N):
        Rnn_n = Rnn[:, :, n]
        sqrt_Rnn_inv = inv(sqrtm(Rnn_n))
        H[:, :, n] = sqrt_Rnn_inv @ H[:, :, n]

    b = np.zeros(U, dtype=np.float64)
    bsum = np.sum(b)

    cum_index = 0
    user_ind = [0]
    for u in range(1, U):
        cum_index += Lxu[u - 1]
        user_ind.append(cum_index)
    user_ind.append(Lx_sum)

    for u in range(U):
        st = user_ind[u]
        en = user_ind[u + 1]
        for n in range(N):
            Rxx[st:en, st:en, n] = Eu[u] * np.eye(en - st, dtype=np.complex128)
    i = 0
    while True:
        bsum_prev = bsum
        b_prev = b.copy()

        for u in range(U):
            st = user_ind[u]
            en = user_ind[u + 1]
            M_u = np.zeros((en - st, en - st, N), dtype=np.complex128)
            g_u = np.zeros((en - st, N), dtype=np.float64)
            Rnn_un = np.zeros((Ly, Ly, N), dtype=np.complex128)

            for n in range(N):
                Rnn_un[:, :, n] = np.eye(Ly, dtype=np.complex128)
                for v in range(U):
                    if v != u:
                        st_v = user_ind[v]
                        en_v = user_ind[v + 1]
                        Hvn = H[:, st_v:en_v, n]
                        Rxxvn = Rxx[st_v:en_v, st_v:en_v, n]
                        Rnn_un[:, :, n] += Hvn @ Rxxvn @ Hvn.T.conj()

                Hun = H[:, st:en, n]
                sqrt_Rnn_un_inv = inv(sqrtm(Rnn_un[:, :, n]))
                Hun_til = sqrt_Rnn_un_inv @ Hun

                _, s, M_n = svd(Hun_til)
                M_u[:, :, n] = M_n
                g_u[:, n] = s ** 2

            g_flat = g_u.flatten()
            B_u, E_u, L_star = fmwaterfill_gn(g_flat, Eu[u], 0, cb)

            e = E_u.reshape(en - st, N)
            b = np.sum(B_u)

            for n in range(N):
                Rxx[st:en, st:en, n] = M_u[:, :, n] @ np.diag(e[:, n]) @ M_u[:, :, n].T.conj()

        bsum = 0
        for n in range(N):
            I = np.eye(Ly, dtype=np.complex128)
            bsum += (1 / cb) * np.log2(det(I + H[:, :, n] @ Rxx[:, :, n] @ H[:, :, n].T.conj()))
        bsum = np.real(bsum)

        i += 1

        if abs(bsum - bsum_prev) <= 1e-6:
            break
        if i > 1000:
            print(i)
            break

    bs = np.zeros(U, dtype=np.float64)
    bsum_lin = 0
    for u in range(U):
        indices = slice(user_ind[u], user_ind[u] + Lxu[u])
        for n in range(N):
            I = np.eye(Ly, dtype=np.complex128)
            term1 = np.log2(det(I + H[:, :, n] @ Rxx[:, :, n] @ H[:, :, n].T.conj()))
            term2 = np.log2(det(I + H[:, :, n] @ Rxx[:, :, n] @ H[:, :, n].T.conj() - H[:, indices, n] @ Rxx[indices, indices, n] @ H[:, indices, n].T.conj()))
            bs[u] += (1 / cb) * (term1 - term2)
        bsum_lin += np.real(bs[u])

    return Rxx, bsum, bsum_lin, B_u, E_u
