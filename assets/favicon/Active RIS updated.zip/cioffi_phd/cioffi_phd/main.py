import os
import pprint
import warnings
import gymnasium as gym
import numpy as np
import torch
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.evaluation import evaluate_policy
from environment import Environment  # Make sure to adjust the import path if needed

# Set up plotting and device configurations
from matplotlib import pyplot as plt
plt.rcParams["font.family"] = "cmr10"
plt.rcParams["axes.formatter.use_mathtext"] = True
plt.rcParams["figure.figsize"] = (8, 6)

device = "cuda" if torch.cuda.is_available() else "cpu"

# Disable warnings
warnings.filterwarnings("ignore")

# Define callback for learning rate decay
class LearningRateDecayCallback(BaseCallback):
    def _init_(self, learning_rate_fn, verbose=0):
        super()._init_(verbose)
        self.learning_rate_fn = learning_rate_fn

    def _on_step(self) -> bool:
        new_lr = self.learning_rate_fn(self.num_timesteps)
        self.model.learning_rate = new_lr
        return True

# Set up environment
cfg = {
    'M': 4,  # Number of antennas at the BS
    'K': 4,  # Number of users
    'N': 256,  # Number of elements at the RIS
    'max_steps': 100,  # Maximum number of steps in an episode
    'noise_power': 1e-9,  # Noise power
    'total_power_limit': 55  # Total power limit in dBm
}

gym.register(id="RISPrecoding-v0", entry_point=Environment, kwargs={'cfg': cfg})
env = gym.make("RISPrecoding-v0")

# Check the environment
try:
    from stable_baselines3.common.env_checker import check_env
    check_env(env)
except Exception as e:
    print("Environment check failed:", e)
    exit(1)

# Set up directory for saving model and logs
MODEL = "ppo"
save_dir = f"./logss/{MODEL}"
os.makedirs(save_dir, exist_ok=True)

env = Monitor(
    env,
    filename=f"{save_dir}/monitor.csv",
    info_keywords=("R_1", "R_2", "R_3", "P_1", "P_2", "P_3", "total_power"),
)

# Set up PPO model for training
model = PPO(
    "MlpPolicy",
    env,
    verbose=2,
    device=device,
    tensorboard_log=save_dir,
    seed=42,
    batch_size=128,
    n_steps=200,
    gamma=0.98,
    learning_rate=0.0005,  # Learning rate
)

# Callback for dynamic learning rate
lr_callback = LearningRateDecayCallback(learning_rate_fn=lambda step: 0.0005 * (1 - step / 1e6))

# Train the model
model.learn(total_timesteps=100000, callback=lr_callback)

# Save the trained model
model.save(f"{save_dir}/{MODEL}_ris_precoding")

# Load the model for evaluation
model = PPO.load(f"{save_dir}/{MODEL}_ris_precoding")

# Evaluate the trained model
mean_reward, std_reward = evaluate_policy(model, env, n_eval_episodes=10)
print(f"Mean reward: {mean_reward}, Std reward: {std_reward}")

# Testing the model in the environment and collecting data for plotting
obs = env.reset()
done = False
reward_history = []
power_history = []
capacity_gain_history = []

while not done:
    action, _states = model.predict(obs)
    obs, reward, done, info = env.step(action)
    
    # Log the performance metrics
    reward_history.append(reward)
    power_history.append(info.get("total_power", 0))
    capacity_gain_history.append(np.sum([info.get(f"R_{i+1}", 0) for i in range(cfg['K'])]))

    print(f"Current reward (sum-rate): {reward}")

# Plotting the sum-rate reward over episodes
plt.figure()
plt.plot(reward_history)
plt.xlabel('Step')
plt.ylabel('Sum-rate Reward')
plt.title('Sum-rate Reward over Steps')
plt.grid(True)
plt.show()

# Plotting total power usage over episodes
plt.figure()
plt.plot(power_history)
plt.xlabel('Step')
plt.ylabel('Total Power (dBm)')
plt.title('Total Power Usage over Steps')
plt.grid(True)
plt.show()

# Plotting capacity gain over episodes
plt.figure()
plt.plot(capacity_gain_history)
plt.xlabel('Step')
plt.ylabel('Capacity Gain')
plt.title('Capacity Gain over Steps')
plt.grid(True)
plt.show()