import numpy as np
from comyx.network import BaseStation, Link, UserEquipment
from comyx.propagation import get_noise_power
from comyx.utils import db2pow, dbm2pow, generate_seed


def get_cfg():
    # Pt = 30  # Transmit power in dBm
    # Pt_lin = db2pow(Pt)
    bandwidth = 100e6  # Bandwidth in Hz
    frequency = 2.4e9  # Carrier frequency
    temperature = 300  # Kelvin
    n_RX = 2  # Number of receive antennas (BS)
    n_TX = 1  # Number of transmit antennas (UE)
    tones = 64  # Number of subcarriers
    magnitude = False

    sigma2_dbm = get_noise_power(temperature, bandwidth, 6)  # dBm
    sigma2 = dbm2pow(sigma2_dbm)  # Watt
    realizations = 1000 # Number of Monte Carlo simulations

    shape_h = (n_RX, n_TX, tones, realizations)

    seed = 42
    fading_args = {"type": "rayleigh", "sigma": np.sqrt(1 / 2)}
    pathloss_args = {
        "type": "reference",
        "alpha": 3.5,
        "p0": 30,
        "frequency": frequency,
    }  # p0 is the reference power in dBm

    return {
        # "Pt": Pt,
        # "Pt_lin": Pt_lin,
        "bandwidth": bandwidth,
        "frequency": frequency,
        "temperature": temperature,
        "n_RX": n_RX,
        "n_TX": n_TX,
        "tones": tones,
        "magnitude": magnitude,
        "sigma2_dbm": sigma2_dbm,
        "sigma2": sigma2,
        "realizations": realizations,
        "shape_h": shape_h,
        "seed": seed,
        "fading_args": fading_args,
        "pathloss_args": pathloss_args,
        "num_steps": 200,
    }


def init_system(cfg):
    ax_point = BaseStation("AP", cfg["n_TX"], position=[0, 0, 3])
    usr_1 = UserEquipment("UE1", cfg["n_RX"], position=[3, 0, 1])
    usr_2 = UserEquipment("UE1", cfg["n_RX"], position=[0, 3, 1])
    usr_3 = UserEquipment("UE1", cfg["n_RX"], position=[3, 3, 1])

    return ax_point, usr_1, usr_2, usr_3


def init_links(cfg, ax_point, usr_1, usr_2, usr_3):
    link_1 = Link(
        ax_point,
        usr_1,
        cfg["fading_args"],
        cfg["pathloss_args"],
        shape=cfg["shape_h"],
        seed=generate_seed("link_1"),
    )
    link_2 = Link(
        ax_point,
        usr_2,
        cfg["fading_args"],
        cfg["pathloss_args"],
        shape=cfg["shape_h"],
        seed=generate_seed("link_2"),
    )
    link_3 = Link(
        ax_point,
        usr_3,
        cfg["fading_args"],
        cfg["pathloss_args"],
        shape=cfg["shape_h"],
        seed=generate_seed("link_3"),
    )
    H = np.concatenate(
        [link_1.channel_gain, link_2.channel_gain, link_3.channel_gain], axis=1
    )
    return (link_1, link_2, link_3, H)


def get_rates(cfg, H, p_1, p_2, p_3, idx):
    # Initialize arrays to store rates for each tone
    R_1_array = np.zeros(cfg["tones"])
    R_2_array = np.zeros(cfg["tones"])
    R_3_array = np.zeros(cfg["tones"])
    
    for i in range(cfg["tones"]):
        h_1 = H[:, 0, i, idx]  # Shape: (2,)
        h_2 = H[:, 1, i, idx]  # Shape: (2,)
        h_3 = H[:, 2, i, idx]  # Shape: (2,)
        
        magsqr_h_1 = np.sum(np.abs(h_1) ** 2)
        magsqr_h_2 = np.sum(np.abs(h_2) ** 2)
        magsqr_h_3 = np.sum(np.abs(h_3) ** 2)
        
        # Calculate SINRs for the specific realization
        sinr_1 = (p_1 * magsqr_h_1) / (p_2 * magsqr_h_2 + p_3 * magsqr_h_3 + cfg["sigma2"])
        sinr_2 = (p_2 * magsqr_h_2) / (p_3 * magsqr_h_3 + cfg["sigma2"])
        sinr_3 = (p_3 * magsqr_h_3) / cfg["sigma2"]
        
        # Calculate rates for this tone and specific realization
        R_1_array[i] = np.log2(1 + sinr_1) * (cfg["bandwidth"] / cfg["tones"])
        R_2_array[i] = np.log2(1 + sinr_2) * (cfg["bandwidth"] / cfg["tones"])
        R_3_array[i] = np.log2(1 + sinr_3) * (cfg["bandwidth"] / cfg["tones"])
    
    # Calculate total rates across all tones for this specific realization
    R_1 = np.sum(R_1_array)
    R_2 = np.sum(R_2_array)
    R_3 = np.sum(R_3_array)
    
    return float(R_1), float(R_2), float(R_3)




def rescale(x, x_min, x_max):
    """
    Rescale the input in [-1, 1] to [x_min, x_max].

    Args:
        x: Input to be rescaled.
        x_min: Minimum value of the rescaled range.
        x_max: Maximum value of the rescaled range.
    """
    return (x + 1) * (x_max - x_min) / 2 + x_min
