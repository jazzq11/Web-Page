import gymnasium as gym
import numpy as np
from comyx.utils import dbm2pow, pow2dbm
from gymnasium import spaces
from .helper import *
from stable_baselines3.common.callbacks import BaseCallback
from collections import deque

cfg = get_cfg()

class Environment(gym.Env):
    def _init_(self, cfg=cfg, render_mode=None, channel=None):
        super()._init_()
        self.render_mode = render_mode
        self.idx = 0
        self.time_step = 0
        self.cfg = cfg
        self.ax_point, self.usr_1, self.usr_2, self.usr_3 = init_system(cfg)
        if channel is not None:
            self.H = channel
        else:
            _, _, _, self.H = init_links(
                cfg, self.ax_point, self.usr_1, self.usr_2, self.usr_3
            )
        self.P_1 = 0.0
        self.P_2 = 0.0
        self.P_3 = 0.0
        self.R_1 = 0.0
        self.R_2 = 0.0
        self.R_3 = 0.0
        self.min_rate = 50e6  # 50 Mbps minimum rate constraint per user
        self.target_rate = 500e6  # Target rate of 500 Mbps per user
        self.max_power = dbm2pow(50)  # Maximum power in linear scale (50 dBm)
        self.total_power_limit = dbm2pow(55)  # Maximum total power in linear scale (55 dBm)

        # Initialize w, Theta, P (assuming shapes are known or derived from the system setup)
        self.w = np.random.randn(cfg['M'], cfg['K'])  # M x K precoding matrix
        self.theta = np.random.randn(cfg['N'], cfg['M'])  # N x M phase shift matrix
        self.p = np.random.randn(cfg['N'])  # N x 1 amplification matrix

        # Observation and action spaces
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(self.w.size + self.theta.size + self.p.size + self.H.size,), dtype=np.float32
        )
        self.action_space = spaces.Box(
            low=-1, high=1, shape=(self.w.size + self.theta.size + self.p.size,), dtype=np.float32
        )

        # Reward history for debugging or training analysis
        self.reward_history = deque(maxlen=1000)

    def _get_state(self):
        # Combine w, Theta, P, and CSI (H) into a single state vector
        state = np.concatenate([self.w.flatten(), self.theta.flatten(), self.p.flatten(), self.H.flatten()])
        return state

    def apply_action_to_parameters(self, action):
        # Split action into parts for w, Theta, P
        w_action = action[:self.w.size].reshape(self.w.shape)
        theta_action = action[self.w.size:self.w.size + self.theta.size].reshape(self.theta.shape)
        p_action = action[-self.p.size:]

        # Apply the actions (e.g., add the action to the current values, scaled by a learning rate)
        self.w += w_action * 0.01  # Update w with a small step
        self.theta += theta_action * 0.01  # Update Theta with a small step
        self.p += p_action * 0.01  # Update P with a small step

    def calculate_sum_rate(self):
        # Example sum-rate calculation using current w, Theta, P, and H
        # This will need to be adapted based on the actual system model
        interference = np.sum(np.abs(self.H @ self.w) ** 2, axis=0)
        signal = np.abs(self.H @ self.w) ** 2
        noise = np.sum(self.p ** 2) * self.cfg['noise_power']

        rates = np.log2(1 + signal / (interference + noise))
        return rates, np.sum(self.p ** 2)  # Returning rates and total power for reward calculation

    def _get_reward(self, rates, powers):
        # Reward is based on sum-rate, with penalties for violating power constraints
        sum_rate = np.sum(rates)
        penalty = 0
        if powers > self.total_power_limit:
            penalty += 10 * (powers - self.total_power_limit)  # Strong penalty for exceeding power
        return sum_rate - penalty

    def step(self, action):
        # Apply action to w, Theta, P
        self.apply_action_to_parameters(action)
        
        # Calculate sum-rate based on updated parameters
        rates, total_power = self.calculate_sum_rate()

        # Calculate reward
        reward = self._get_reward(rates, total_power)

        # Get the new state
        state = self._get_state()
        
        done = self.check_termination()
        return state, reward, done, {}

    def reset(self):
        # Reset the environment to the initial state
        self.w = np.random.randn(self.cfg['M'], self.cfg['K'])
        self.theta = np.random.randn(self.cfg['N'], self.cfg['M'])
        self.p = np.random.randn(self.cfg['N'])
        return self._get_state()

    def check_termination(self):
        # Define a condition for episode termination
        return self.time_step > self.cfg['max_steps']